/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionBebida;
import modelo.Bebidas;
import restaurante.VentanaBebidas;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteRegistrarBebida implements ActionListener {
//llamos las clases
    VentanaBebidas vtnest;
     Bebidas est;
    ConeccionBebida cnE;
   

    public OyenteRegistrarBebida(VentanaBebidas vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
      est = vtnest.guardarBebidas();
        cnE.guardarBebidasBD(est);
        vtnest.limpiarCamposBebidas();
        JOptionPane.showMessageDialog(null, "Datos registrados");
        vtnest.bloquearCampos();
    }
    
    
}
