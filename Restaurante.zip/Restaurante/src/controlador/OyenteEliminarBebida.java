/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionBebida;
import modelo.Bebidas;
import restaurante.VentanaBebidas;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteEliminarBebida implements ActionListener {
//llamos las clases
    VentanaBebidas vtnest;
    ConeccionBebida cest;
    Bebidas est;

    public OyenteEliminarBebida(VentanaBebidas vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       //enviamos un mensaje de confirmacion 
        int resp = JOptionPane.showConfirmDialog(null, "Eliminar Datos", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (resp == JOptionPane.YES_OPTION) {
        cest.eliminarBebidaBD(vtnest.eliminarBebidas());
        JOptionPane.showMessageDialog(null, "La bebida ha sido eliminada");
        vtnest.limpiarCamposBebidas();

         } else if (resp == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "La bebida no ha sido eliminada");

        }
    
    }
    
}
