/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import javax.swing.table.DefaultTableModel;
import restaurante.Menu;
import java.sql.ResultSet;

/**
 *
 * @author Bladilu_xxx
 */
public class CargarBase {

//cargo los registros de la tabla platos de mysql en la tabla platillos
    public void mostrarb() {
//defino el modelo
        DefaultTableModel modelo = new DefaultTableModel();
        // hago la consulat
        ResultSet rs = ConectarBase.getTabla("select nombres,precio from platos");
        // defino los campos a a crear  en a tabla platillos
        modelo.setColumnIdentifiers(new Object[]{"Nombres", "Precio"});
        try {
            // mientras haya registros
            while (rs.next()) {
                // añade los resultado a el modelo de tabla platillos
                modelo.addRow(new Object[]{rs.getString("nombres"), rs.getString("precio")});
            }
            // asigna el modelo a la tabla
            Menu.JTPlatos.setModel(modelo);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void mostrarclientes() {
//defino el modelo
        DefaultTableModel modelo0 = new DefaultTableModel();
        // hago la consulat
        ResultSet rs = ConectarBase.getTabla("select idcliente,nombres,apellidos from clientes");
        // defino los campos a a crear  en a tabla platillos
        modelo0.setColumnIdentifiers(new Object[]{"Idcliente", "Nombres", "Apellidos"});
        try {
            // mientras haya registros
            while (rs.next()) {
                // añade los resultado a el modelo de tabla platillos
                modelo0.addRow(new Object[]{rs.getString("idcliente"), rs.getString("nombres"), rs.getString("apellidos")});
            }
            // asigna el modelo a la tabla
            Menu.tablacientesM.setModel(modelo0);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    //cargo los registros de la tabla bebidas de mysql en la tabla bebidas
    public void mostrar() {
//defino el modelo
        DefaultTableModel modelo = new DefaultTableModel();
        //realizo la consulta
        ResultSet rs = ConectarBase.getTabla("select nombres,precio from bebidas");
        //defino los campos a crear en la tabla bebidas
        modelo.setColumnIdentifiers(new Object[]{"Nombres", "Precio"});
        try {
            // mientras haya registros
            while (rs.next()) {
                // añade los resultado a el modelo de tabla bebidas
                modelo.addRow(new Object[]{rs.getString("nombres"), rs.getString("precio")});
            }
            // asigna el modelo a la tabla
            Menu.JTBebidas.setModel(modelo);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
