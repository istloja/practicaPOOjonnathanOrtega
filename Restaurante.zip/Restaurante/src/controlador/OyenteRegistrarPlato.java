/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionPlato;
import modelo.Platos;
import restaurante.VentanaPlatos;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteRegistrarPlato 
implements ActionListener {
//llamos las clases
    VentanaPlatos vtnest;
     Platos est;
    ConeccionPlato cnE;
   

    public OyenteRegistrarPlato(VentanaPlatos vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
      est = vtnest.guardarPlatos();
        cnE.guardarPlatosBD(est);
        vtnest.limpiarCamposPlatos();
        JOptionPane.showMessageDialog(null, "Datos registrados");
        vtnest.bloquearCampos();
    }
    
}
