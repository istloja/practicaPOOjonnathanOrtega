/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionCliente;
import modelo.Clientes;
import restaurante.Factura;
import restaurante.VentanaClientes;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteBuscarCliente
        implements ActionListener {
    
//llamos las clases
    VentanaClientes vtnest;
    ConeccionCliente cnest;
    Clientes est;
    Factura tu;

    public OyenteBuscarCliente(VentanaClientes vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        est = cnest.buscarClientes(vtnest.verificarCliente());
        // no esta llamar
        

        if (est.getIdcliente()== null) {
            //si no se encuentra havulita los campos para registrar
            vtnest.desbloquearCampos();
            vtnest.bloquearCampos();

            JOptionPane.showMessageDialog(null, "cliente no registrado");
            int resp = JOptionPane.showConfirmDialog(null, "Registar cliente ", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                vtnest.desbloquearCampos();
               // vtnest.limpiarCamposClientes();

            } else if (resp == JOptionPane.NO_OPTION) {
                vtnest.desbloquearCampos();
                vtnest.limpiarCamposClientes();

            }

        } else {
                //si se encuentra registrado lo llama a los campos

            vtnest.desbloquearCampos();
            vtnest.limpiarCamposClientes();
            //  vtnest.bloquearCampos();
            vtnest.cargarCampos(est);

        }
    }

}
