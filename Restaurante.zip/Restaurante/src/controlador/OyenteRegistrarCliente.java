/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionCliente;
import modelo.Clientes;
import restaurante.VentanaClientes;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteRegistrarCliente implements ActionListener {
//llamos las clases
    VentanaClientes vtnest;
     Clientes est;
    ConeccionCliente cnE;
   

    public OyenteRegistrarCliente(VentanaClientes vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // actualizo la tabla clientes
          CargarBase n = new CargarBase();
        // llamo al metodo cargar platos
       
        
      est = vtnest.guardarClientes();
        cnE.guardarClientesBD(est);
        vtnest.limpiarCamposClientes();
        JOptionPane.showMessageDialog(null, "Datos registrados");
        vtnest.bloquearCampos();
         n.mostrarclientes();
    }
    
    
}
