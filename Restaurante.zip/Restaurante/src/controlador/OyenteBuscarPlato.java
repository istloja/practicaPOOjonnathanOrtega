/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionPlato;
import modelo.Platos;
import restaurante.VentanaPlatos;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteBuscarPlato implements ActionListener {
//llamos las clases
    VentanaPlatos vtnest;
    ConeccionPlato cnest;
    Platos est;

    public OyenteBuscarPlato(VentanaPlatos vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        est = cnest.buscarPlatos(vtnest.verificarPlato());
        // no esta llamar

        if (est.getIdplato()== null) {
            //si no se encuentra havulita los campos para registrar
vtnest.desbloquearCampos();
            vtnest.bloquearCampos();
            
            JOptionPane.showMessageDialog(null, "Platillo no registardo");
            int resp = JOptionPane.showConfirmDialog(null, "Registar platillo ","", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                vtnest.desbloquearCampos();
                vtnest.limpiarCamposPlatos();
                
            } else if (resp == JOptionPane.NO_OPTION) {
              vtnest.desbloquearCampos();
                vtnest.limpiarCamposPlatos();
                
               
            }

            } else {
                //si se encuentra registrado lo llama a los campos

                
                vtnest.desbloquearCampos();
                vtnest.limpiarCamposPlatos();
              //  vtnest.bloquearCampos();
                vtnest.cargarCampos(est);

            }
        }

    }
