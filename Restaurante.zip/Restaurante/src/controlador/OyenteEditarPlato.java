/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionPlato;
import modelo.Platos;
import restaurante.VentanaPlatos;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteEditarPlato implements ActionListener {
//llamos las clases
    VentanaPlatos vp;
    ConeccionPlato cnest;
    Platos est;

    public OyenteEditarPlato(VentanaPlatos vtnest) {
        this.vp = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
         vp.desbloquearCampos();
        est = vp.guardarPlatos();
        cnest.editarPlatos(est);
        JOptionPane.showMessageDialog(null, "Sus cambios han sido registrados ");
        vp.limpiarCamposPlatos();
    }
    
    
}
