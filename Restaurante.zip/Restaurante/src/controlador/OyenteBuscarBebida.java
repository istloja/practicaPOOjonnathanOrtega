/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConeccionBebida;
import modelo.Bebidas;
import restaurante.VentanaBebidas;

/**
 *
 * @author Bladilu_xxx
 */
public class OyenteBuscarBebida
        implements ActionListener {
//llamos las clases

    VentanaBebidas vtnest;
    ConeccionBebida cnest;
    Bebidas est;

    public OyenteBuscarBebida(VentanaBebidas vtnest) {
        this.vtnest = vtnest;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    
//bebidas=coneccionbebida(llamo a un metodo de ventanabebidas
        est = cnest.buscarBebidas(vtnest.verificarBebida());
        // no esta llamar

        if (est.getIdbebida() == null) {
            //si no se encuentra abilita los campos para registrar
            vtnest.desbloquearCampos();
            vtnest.bloquearCampos();

            JOptionPane.showMessageDialog(null, "bebida no registrada");
            int resp = JOptionPane.showConfirmDialog(null, "Registar bebida ", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                vtnest.desbloquearCampos();
                vtnest.limpiarCamposBebidas();

            } else if (resp == JOptionPane.NO_OPTION) {
                vtnest.desbloquearCampos();
                vtnest.limpiarCamposBebidas();

            }

        } else {
                //si se encuentra registrado lo llama a los campos

            vtnest.desbloquearCampos();
            vtnest.limpiarCamposBebidas();
            vtnest.cargarCampos(est);

        }
    }

}
