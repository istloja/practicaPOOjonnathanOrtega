/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

import controlador.OyenteBuscarCliente;
import controlador.OyenteEditarCliente;
import controlador.OyenteEliminarCliente;
import controlador.OyenteRegistrarCliente;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import modelo.Clientes;

/**
 *
 * @author Bladilu_xxx
 */
public class VentanaClientes extends JFrame {

  
    

    JLabel lnombres = new JLabel("Nombres");
    JLabel lapellidos = new JLabel("Apellidos");
    JLabel lidcliente = new JLabel("Cedula");
    JTextField txtid = new JTextField(10);
    JTextField txtNombres = new JTextField(10);
    JTextField txtApellidos = new JTextField(10);
    JButton btnGuardar = new JButton("Guardar");
    JButton btnBuscar = new JButton("Buscar");
    JButton btnEditar = new JButton("Editar");
    JButton btnEliminar = new JButton("Eliminar");
    JButton btnSalir = new JButton("Atras");
    JButton btndesbloquear = new JButton("Havilitar");
    JPanel panel = new JPanel();
     JPanel panel1 = new JPanel();
    Panel fondo = new Panel();
    Clientes est = new Clientes();
  
    public VentanaClientes() {

        super("DATOS Clientes");
        
        setSize(1100, 500);
        setLocation(200, 200);
        setResizable(true);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        AgregarComponentes();
       
        bloquearCampos();
       

    }

    public void AgregarComponentes() {
       

        getContentPane().add(fondo);
        fondo.setLayout(new GridBagLayout());
        GridBagConstraints a = new GridBagConstraints();
        a.gridx = 0;
        a.gridy = 0;
        fondo.add(lidcliente, a);
        a.gridx = 1;
        a.gridy = 0;
        fondo.add(txtid, a);
        a.gridx = 0;
        a.gridy = 1;
        fondo.add(lnombres, a);
        a.gridx = 1;
        a.gridy = 1;
        fondo.add(txtNombres, a);
        a.gridx = 0;
        a.gridy = 2;
        fondo.add(lapellidos, a);
        a.gridx = 1;
        a.gridy = 2;
        fondo.add(txtApellidos, a);
        a.gridx = 1;
        a.gridy = 4;
        fondo.add(panel, a);
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        panel.add(btnEditar, c);
        btnEditar.addActionListener(new OyenteEditarCliente(this));//damos la accion al boton
        c.gridx = 2;
        c.gridy = 0;
        panel.add(btnEliminar, c);
        btnEliminar.addActionListener(new OyenteEliminarCliente(this));//damos la accion al boton
        
        c.gridx = 4;
        c.gridy = 0;
        panel.add(btnBuscar, c);
        btnBuscar.addActionListener(new OyenteBuscarCliente(this));//damos la accion al boton
        c.gridx = 5;
        c.gridy = 1;
        fondo.add(btndesbloquear, a);

        btndesbloquear.addActionListener(new havilitar());//damos la accion al boton
        c.gridx = 6;
        c.gridy = 0;
        panel.add(btnGuardar, c);
        btnGuardar.addActionListener(new OyenteRegistrarCliente(this));//damos la accion al boton
         a.gridx = 1;
        a.gridy = 7;
        fondo.add(panel1, a);
        panel1.setLayout(new GridBagLayout());
        GridBagConstraints e = new GridBagConstraints();
        e.gridx = 0;
        e.gridy = 6;
        panel1.add(btnSalir, e);
        btnSalir.addActionListener(new OyenteSalir());//damos la accion al boton

    }

    public Clientes guardarClientes() {

        est = new Clientes();
        est.setIdcliente(txtid.getText());
        est.setNombres(txtNombres.getText());
        est.setApellidos(txtApellidos.getText());

        return est;
    }

    public void limpiarCamposClientes() {
        txtid.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
    }

    public void bloquearCampos() {
        //  txtfCedula.setEditable(false);
        txtNombres.setEditable(false);
        txtApellidos.setEditable(false);
    }

    public void desbloquearCampos() {
        txtid.setEditable(true);
        txtNombres.setEditable(true);
        txtApellidos.setEditable(true);
    }

    public String verificarCliente() {
        
        return txtid.getText();
    }
     public String idCliente() {
        return txtid.getText();
    }

    public void cargarCampos(Clientes clientes) {

        txtid.setText(clientes.getIdcliente());
        txtNombres.setText(clientes.getNombres());
        txtApellidos.setText(clientes.getApellidos());

    }

    public String eliminarClientes() {
        return txtid.getText();
    }

    public class OyenteSalir implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == btnSalir) {
                dispose();
            }
        }
    }

    public class havilitar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == btndesbloquear) {
                desbloquearCampos();
                limpiarCamposClientes();

            }

        }
    }

    public static void main(String[] args) {
        new VentanaClientes();
    }

}
