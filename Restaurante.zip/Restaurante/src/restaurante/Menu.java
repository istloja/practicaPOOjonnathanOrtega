/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

import controlador.CargarBase;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static restaurante.Factura.txtTotaliva;

/**
 *
 * @author Bladilu_xxx
 */
public class Menu extends javax.swing.JFrame {

    public Menu() {

        // inicio los  componentes
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        JTBebidas = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        Bañadir1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        JTPlatos = new javax.swing.JTable();
        Bañadir = new javax.swing.JButton();
        Btotal = new javax.swing.JButton();
        txtTotal = new javax.swing.JTextField();
        ltxtTotal = new javax.swing.JLabel();
        Bfactura = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        BVSalir = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablacientesM = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JTBebidas.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        JTBebidas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "         Nombre", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JTBebidas.setColumnSelectionAllowed(true);
        JTBebidas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        JTBebidas.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(JTBebidas);
        JTBebidas.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (JTBebidas.getColumnModel().getColumnCount() > 0) {
            JTBebidas.getColumnModel().getColumn(1).setMinWidth(50);
            JTBebidas.getColumnModel().getColumn(1).setPreferredWidth(50);
            JTBebidas.getColumnModel().getColumn(1).setMaxWidth(50);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 250, 370));

        tabla.setBackground(new java.awt.Color(255, 204, 204));
        tabla.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 0)));
        tabla.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "", "Cantidad"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabla.setGridColor(new java.awt.Color(51, 51, 255));
        tabla.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(tabla);
        if (tabla.getColumnModel().getColumnCount() > 0) {
            tabla.getColumnModel().getColumn(1).setMinWidth(0);
            tabla.getColumnModel().getColumn(1).setPreferredWidth(12);
            tabla.getColumnModel().getColumn(1).setMaxWidth(0);
            tabla.getColumnModel().getColumn(2).setMinWidth(60);
            tabla.getColumnModel().getColumn(2).setPreferredWidth(60);
            tabla.getColumnModel().getColumn(2).setMaxWidth(60);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 70, 250, 290));

        Bañadir1.setText("AGREGAR");
        Bañadir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Bañadir1ActionPerformed(evt);
            }
        });
        getContentPane().add(Bañadir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 150, 40));

        JTPlatos.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JTPlatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JTPlatos.setColumnSelectionAllowed(true);
        JTPlatos.setInheritsPopupMenu(true);
        JTPlatos.setSelectionBackground(new java.awt.Color(255, 255, 153));
        JTPlatos.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(JTPlatos);
        JTPlatos.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (JTPlatos.getColumnModel().getColumnCount() > 0) {
            JTPlatos.getColumnModel().getColumn(1).setMinWidth(50);
            JTPlatos.getColumnModel().getColumn(1).setPreferredWidth(5);
            JTPlatos.getColumnModel().getColumn(1).setMaxWidth(50);
        }

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 250, 370));

        Bañadir.setText("AGREGAR");
        Bañadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BañadirActionPerformed(evt);
            }
        });
        getContentPane().add(Bañadir, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 450, 150, 40));

        Btotal.setText("Total");
        Btotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtotalActionPerformed(evt);
            }
        });
        getContentPane().add(Btotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 380, 120, 30));

        txtTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });
        getContentPane().add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 420, 80, 20));
        getContentPane().add(ltxtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 300, -1, -1));

        Bfactura.setText("Generar Factura");
        Bfactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BfacturaActionPerformed(evt);
            }
        });
        getContentPane().add(Bfactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 470, 140, 40));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bebidas.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 60));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/platillos.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 260, 60));

        BVSalir.setText("Atras");
        BVSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BVSalirActionPerformed(evt);
            }
        });
        getContentPane().add(BVSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 80, 20));

        jButton1.setText("Agregar Cliente");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 280, -1, -1));

        tablacientesM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "cedula", "Nombre", "Apellido"
            }
        ));
        jScrollPane4.setViewportView(tablacientesM);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 80, 210, 190));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/final f.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Bañadir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Bañadir1ActionPerformed
// fijo la tabla de bebidas al modelo1
        TableModel modelo1 = JTBebidas.getModel();
// creo un array para guardar la fila selecionada 
        int[] filas = JTBebidas.getSelectedRows();
        int ca = 0;

        Object[] row = new Object[2];
        // envio las filas selecionadas a la tabla 
        DefaultTableModel modelo2 = (DefaultTableModel) tabla.getModel();
// mediante un for envio las filas seleccinadas 
        for (int i = 0; i < filas.length; i++) {
            // seleciono las columnas que voy a enviar recordadndo que nombre esta en la posicion 0 y precio en la posicion 1
            row[0] = modelo1.getValueAt(filas[i], 0);
            row[1] = modelo1.getValueAt(filas[i], 1);

            modelo2.addRow(row);
        }
    }//GEN-LAST:event_Bañadir1ActionPerformed

    private void BañadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BañadirActionPerformed
// fijo la tabla de bebidas al modelo3
        TableModel modelo3 = JTPlatos.getModel();
        // creo un array para guardar la fila selecionada
        int[] filas1 = JTPlatos.getSelectedRows();
        Object[] row = new Object[2];
        // envio las filas selecionadas a la tabla 
        DefaultTableModel modelo2 = (DefaultTableModel) tabla.getModel();
// mediante un for envio las filas seleccinadas 
        for (int j = 0; j < filas1.length; j++) {
            // seleciono las columnas que voy a enviar recordadndo que nombre esta en la posicion 0 y precio en la posicion 1
            row[0] = modelo3.getValueAt(filas1[j], 0);
            row[1] = modelo3.getValueAt(filas1[j], 1);

            modelo2.addRow(row);
        }
    }//GEN-LAST:event_BañadirActionPerformed

    private void BtotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtotalActionPerformed

// pongo el valor de 0 al campo total en caso de que no selecione ningun platillo o bebida
        txtTotal.setText("0");
        // fijo el total de registros  de la tabla a ala variable t
        int t = tabla.getRowCount();
        // declaro el contador
        int c = 0;
// delaro el resultado del total
        double re = 0;
        // mediante un while saco el total a pagar
        do {

            try {
// fijo el contador a f 
                int f = c++;
                //guardo el precio en la variable n1 que se encuentra en la columna 1
                double n1 = Double.parseDouble(tabla.getValueAt(f, 1).toString());
                //guardo la cantidad   variable n2 que se encuentra en la columna 2
                double n2 = Double.parseDouble(tabla.getValueAt(f, 2).toString());
// sumno y multiplico el preecio por la cantidad y guardo en la variable re
                re = re + n1 * n2;
// muestro el resulatdo en el campo txtTotal
                txtTotal.setText(String.valueOf(re));

            } catch (Exception e) {
                System.out.println("errror");
            }
            // mientras la cantidad de registros no sea igual a contador
        } while (c <= t);
    }//GEN-LAST:event_BtotalActionPerformed

    private void BfacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BfacturaActionPerformed

        Factura n = new Factura();
// muestro la ventana
        new Factura().setVisible(true);
        // defino el iva
        double Piva = 0.12;
        // convierto sitrng a double
        double total = Double.parseDouble(txtTotal.getText());
        // saco el iva
        double iva = total * Piva;
        // saco el total a pagar incluido el iva
        double totalmasIva = iva + total;
        // convierto double a string
        String Tiva = String.valueOf(iva);
        // mando el iva campo  Factura
        Factura.txtTotaliva.setText(Tiva);

        // convierto double a string
        String totalmasIvaS = String.valueOf(totalmasIva);
        // mando precio a Factura
        Factura.txtTotalF.setText(totalmasIvaS);
        // mando los datos de tabla a tablaF de factura
        TableModel model = tabla.getModel();
        Factura.tablaF.setModel(model);
        //envio la fecha a ventana factura
        String Billdate = "dd-MM-yyyy";

        DateFormat sdf = new SimpleDateFormat(Billdate);

        java.util.Date dt = new java.util.Date(); //current date

        sdf.format(dt.getTime());
        String h = sdf.format(dt.getTime());
        Factura.lFecha.setText(h);

        // fijo la tabla de bebidas al modelo1
        TableModel modelo0 = tablacientesM.getModel();
// creo un array para guardar la fila selecionada 
        int[] filas0 = tablacientesM.getSelectedRows();

        Object[] row = new Object[2];
        // envio las filas selecionadas a la tabla 
        DefaultTableModel modelo01 = (DefaultTableModel) Factura.tablaclienteF.getModel();
// mediante un for envio las filas seleccinadas 
        for (int i = 0; i < filas0.length; i++) {
            // seleciono las columnas que voy a enviar recordadndo que nombre esta en la posicion 0 y precio en la posicion 1
            row[0] = modelo0.getValueAt(filas0[i], 0);
            row[1] = modelo0.getValueAt(filas0[i], 1);
            
           
            modelo01.addRow(row);
        }


    }//GEN-LAST:event_BfacturaActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalActionPerformed

    private void BVSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BVSalirActionPerformed

        dispose();

    }//GEN-LAST:event_BVSalirActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new VentanaClientes().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BVSalir;
    private javax.swing.JButton Bañadir;
    private javax.swing.JButton Bañadir1;
    private javax.swing.JButton Bfactura;
    private javax.swing.JButton Btotal;
    public static javax.swing.JTable JTBebidas;
    public static javax.swing.JTable JTPlatos;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel ltxtTotal;
    public static javax.swing.JTable tabla;
    public static javax.swing.JTable tablacientesM;
    public static javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
