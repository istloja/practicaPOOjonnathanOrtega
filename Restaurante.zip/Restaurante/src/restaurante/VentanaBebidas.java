/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;
import controlador.OyenteBuscarBebida;
import controlador.OyenteEditarBebida;
import controlador.OyenteEliminarBebida;
import controlador.OyenteRegistrarBebida;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import modelo.Bebidas;


/**
 *
 * @author Bladilu_xxx
 */
public class VentanaBebidas 
    extends JFrame {

    JLabel lnombre = new JLabel("Nombre");
    JLabel lprecio = new JLabel("Precio");
    JLabel lidplato = new JLabel("Codigo");
    JTextField txtid = new JTextField(10);
    JTextField txtfNombres = new JTextField(10);
    JTextField txtprecio = new JTextField(10);
    JButton btnGuardar = new JButton("Guardar");
    JButton btnBuscar = new JButton("Buscar");
    JButton btnEditar = new JButton("Editar");
    JButton btnEliminar = new JButton("Eliminar");
    JButton btnSalir = new JButton("Atras");
    JButton btndesbloquear = new JButton("Havilitar");
    JPanel panel = new JPanel();
    Panel fondo = new Panel();
    Bebidas est = new Bebidas();

    public VentanaBebidas() {

        super("DATOS Bebidas");
        setSize(1100, 400);
        setLocation(200, 200);
        setResizable(true);
        setVisible(true);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        AgregarComponentes();
        bloquearCampos();

    }

    public void AgregarComponentes() {

        getContentPane().add(fondo);
        fondo.setLayout(new GridBagLayout());
        GridBagConstraints a = new GridBagConstraints();
        a.gridx = 0;
        a.gridy = 0;
        fondo.add(lidplato, a);
        a.gridx = 1;
        a.gridy = 0;
        fondo.add(txtid, a);
        a.gridx = 0;
        a.gridy = 1;
        fondo.add(lnombre, a);
        a.gridx = 1;
        a.gridy = 1;
        fondo.add(txtfNombres, a);
        a.gridx = 0;
        a.gridy = 2;
        fondo.add(lprecio, a);
        a.gridx = 1;
        a.gridy = 2;
        fondo.add(txtprecio, a);
        a.gridx = 1;
        a.gridy = 5;
        fondo.add(panel, a);
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        panel.add(btnEditar, c);
        btnEditar.addActionListener(new OyenteEditarBebida(this));//damos la accion al boton
        c.gridx = 2;
        c.gridy = 0;
        panel.add(btnEliminar, c);
        btnEliminar.addActionListener(new OyenteEliminarBebida(this));//damos la accion al boton
        c.gridx = 4;
        c.gridy = 5;
        panel.add(btnSalir, c);
        btnSalir.addActionListener(new OyenteSalir());//damos la accion al boton
        c.gridx = 4;
        c.gridy = 0;
        panel.add(btnBuscar, c);
        btnBuscar.addActionListener(new OyenteBuscarBebida(this));//damos la accion al boton
        c.gridx = 5;
        c.gridy = 1;
        fondo.add(btndesbloquear, a);

        btndesbloquear.addActionListener(new havilitar());//damos la accion al boton
        c.gridx = 6;
        c.gridy = 0;
        panel.add(btnGuardar, c);
        btnGuardar.addActionListener(new OyenteRegistrarBebida(this));//damos la accion al boton

    }

    public Bebidas guardarBebidas() {

        est = new Bebidas();
        est.setIdbebida(txtid.getText());
        est.setNombres(txtfNombres.getText());
        double a = Double.parseDouble(txtprecio.getText());
        est.setPrecio(a);
        return est;
    }

    public void limpiarCamposBebidas() {
        txtid.setText("");
        txtfNombres.setText("");
        txtprecio.setText("");
    }

    public void bloquearCampos() {
        //  txtfCedula.setEditable(false);
        txtfNombres.setEditable(false);
        txtprecio.setEditable(false);
    }

    public void desbloquearCampos() {
        txtid.setEditable(true);
        txtfNombres.setEditable(true);
        txtprecio.setEditable(true);
    }

    public String verificarBebida() {
        return txtid.getText();
    }

    public void cargarCampos(Bebidas bebidas) {

        txtid.setText(bebidas.getIdbebida());
        txtfNombres.setText(bebidas.getNombres());
        // transformo de double a String
        String a = String.valueOf(bebidas.getPrecio());
        txtprecio.setText(a);
    }

    public String eliminarBebidas() {
        return txtid.getText();
    }

    public class OyenteSalir implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == btnSalir) {
                // cerrar ventana
                dispose();
            }
        }
    }

    public class havilitar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == btndesbloquear) {
                desbloquearCampos();
                limpiarCamposBebidas();

            }

        }
    }
    public static void main(String[] args) {
        VentanaBebidas j=new VentanaBebidas();
    }

   
    
}
