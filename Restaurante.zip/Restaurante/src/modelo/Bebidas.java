/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Bladilu_xxx
 */
public class Bebidas {
    // inserto : constructor vacio,constructor de todos ,getters and seters ,to string
     private String Nombres,idbebida;
     private double precio;

    public Bebidas() {
    }

    public Bebidas(String Nombres, String idbebida, double precio) {
        this.Nombres = Nombres;
        this.idbebida = idbebida;
        this.precio = precio;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getIdbebida() {
        return idbebida;
    }

    public void setIdbebida(String idbebida) {
        this.idbebida = idbebida;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Bebidas{" + "Nombres=" + Nombres + ", idbebida=" + idbebida + ", precio=" + precio + '}';
    }
    
}
