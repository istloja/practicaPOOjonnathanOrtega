/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Bladilu_xxx
 */
public class ConeccionBebida {
     public static void guardarBebidasBD(Bebidas bebidas) {
        //metimos este metodo dentro de la base de datos 
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //ingresamos la direccion donde se encuntra la base de datos 
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.println("Conexion establecida!");
            Statement sentencia = (Statement) conexion.createStatement();
            // consulta
            int insert = sentencia.executeUpdate("insert into bebidas values("
                    + "'" + bebidas.getIdbebida()
                    + "','" + bebidas.getNombres()
                    + "','" + bebidas.getPrecio()
                    + "')");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.println("Error en la conexion" + ex);
        }
    }

    public static Bebidas buscarBebidas(String idbebida) {
        //meter este método a la base de datos<
        Bebidas estb = new Bebidas();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            ResultSet necesario = sentencia.executeQuery("select * from bebidas where idbebida ='" + idbebida + "'");

            while (necesario.next()) {

                String cedu = necesario.getString("idbebida");
                String nombr = necesario.getString("Nombres");

                String apee = necesario.getString("precio");
                estb.setIdbebida(cedu);
                estb.setNombres(nombr);
                // transformo String a double
                double aa = Double.parseDouble(apee);
                estb.setPrecio(aa);

            }
            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
        return estb;
    }

    //con este metodo editamos un dato ingresado

    public static void editarBebidas(Bebidas bebidas) {
        //metimos este método a la base de datos
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("update bebidas set "
                    + "idbebida='" + bebidas.getIdbebida()
                    + "',Nombres='" + bebidas.getNombres()
                    + "',precio='" + bebidas.getPrecio()
                    + "'where idbebida='" + bebidas.getIdbebida()+ "';");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }
     public static void eliminarBebidaBD(String idbebida) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion Establecida");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("delete from bebidas where idbebida = '" + idbebida + "'");

            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }
    
}
