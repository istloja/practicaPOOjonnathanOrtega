/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import restaurante.Factura;

/**
 *
 * @author Bladilu_xxx
 */
public class ConeccionCliente {
     public static void guardarClientesBD(Clientes clientes) {
        //metimos este metodo dentro de la base de datos 
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //ingresamos la direccion donde se encuntra la base de datos 
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.println("Conexion establecida!");
            Statement sentencia = (Statement) conexion.createStatement();
            int insert = sentencia.executeUpdate("insert into clientes values("
                    + "'" + clientes.getIdcliente()
                    + "','" + clientes.getNombres()
                    + "','" + clientes.getApellidos()
                    + "')");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.println("Error en la conexion" + ex);
        }
    }

    public static Clientes buscarClientes(String idcliente) {
        //meter este método a la base de datos<
        Clientes estb = new Clientes();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            ResultSet necesario = sentencia.executeQuery("select * from clientes where idcliente ='" + idcliente + "'");

            while (necesario.next()) {

                String cedu = necesario.getString("idcliente");
                String nombr = necesario.getString("nombres");

                String apee = necesario.getString("apellidos");
                

                estb.setIdcliente(cedu);
                estb.setNombres(nombr);
                 estb.setApellidos(apee);
                

            }
            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
        return estb;
    }

    //con este metodo editamos un dato ingresado

    public static void editarClientes(Clientes clientes) {
        //metimos este método a la base de datos
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("update clientes set "
                    + "idcliente='" + clientes.getIdcliente()
                    + "',nombres='" + clientes.getNombres()
                    + "',apellidos='" + clientes.getApellidos()
                    + "'where idcliente='" + clientes.getIdcliente()+ "';");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }
     public static void eliminarClienteBD(String idcliente) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion Establecida");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("delete from clientes where idcliente = '" + idcliente + "'");

            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }
    
}
