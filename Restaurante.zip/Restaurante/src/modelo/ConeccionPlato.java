/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Bladilu_xxx
 */
public class ConeccionPlato {

  //  public static ArrayList<Platos> listaPlatos;
//co  este metodo guardamos los datos dentro de la base de datos 

    public static void guardarPlatosBD(Platos platos) {
        //metimos este metodo dentro de la base de datos 
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //ingresamos la direccion donde se encuntra la base de datos 
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.println("Conexion establecida!");
            Statement sentencia = (Statement) conexion.createStatement();
            int insert = sentencia.executeUpdate("insert into platos values("
                    + "'" + platos.getIdplato()
                    + "','" + platos.getNombres()
                    + "','" + platos.getPrecio()
                    + "')");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.println("Error en la conexion" + ex);
        }
    }

    public static Platos buscarPlatos(String idplato) {
        //meter este método a la base de datos
        Platos est = new Platos();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            ResultSet necesario = sentencia.executeQuery("select * from platos where idplato ='" + idplato + "'");

            while (necesario.next()) {

                String ced = necesario.getString("idplato");
                String nomb = necesario.getString("Nombres");

                String ape = necesario.getString("precio");

                est.setIdplato(ced);
                est.setNombres(nomb);
                double a = Double.parseDouble(ape);
                est.setPrecio(a);

            }
            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
        return est;
    }

    //con este metodo editamos un dato ingresado

    public static void editarPlatos(Platos platos) {
        //metimos este método a la base de datos
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion establecida!");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("update platos set "
                    + "idplato='" + platos.getIdplato()
                    + "',Nombres='" + platos.getNombres()
                    + "',precio='" + platos.getPrecio()
                    + "'where idplato='" + platos.getIdplato() + "';");

            sentencia.close();
            conexion.close();

        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }
     public static void eliminarPlatoBD(String idplato) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/Restaurante", "root", "root");
            System.out.print("Conexion Establecida");
            Statement sentencia = conexion.createStatement();
            int insert = sentencia.executeUpdate("delete from platos where idplato = '" + idplato + "'");

            sentencia.close();
            conexion.close();
        } catch (Exception ex) {
            System.out.print("Error en la conexion" + ex);
        }
    }

}
