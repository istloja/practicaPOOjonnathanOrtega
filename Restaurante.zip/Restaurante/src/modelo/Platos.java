/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Bladilu_xxx
 */
public class Platos {
     private String Nombres,idplato;
     private double precio;
     

    public Platos() {
    }

    public Platos(String Nombres, String idplato, double precio) {
        this.Nombres = Nombres;
        this.idplato = idplato;
        this.precio = precio;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getIdplato() {
        return idplato;
    }

    public void setIdplato(String idplato) {
        this.idplato = idplato;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Platos{" + "Nombres=" + Nombres + ", idplato=" + idplato + ", precio=" + precio + '}';
    }
    

    
    
}
