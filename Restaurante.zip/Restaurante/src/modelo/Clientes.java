/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Bladilu_xxx
 */
public class Clientes {
      private String idcliente,Nombres,Apellidos;

    public Clientes() {
    }

    public Clientes(String idcliente, String Nombres, String Apellidos) {
        this.idcliente = idcliente;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
    }

    public String getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(String idcliente) {
        this.idcliente = idcliente;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    @Override
    public String toString() {
        return "Clientes{" + "idcliente=" + idcliente + ", Nombres=" + Nombres + ", Apellidos=" + Apellidos + '}';
    }
    
}
